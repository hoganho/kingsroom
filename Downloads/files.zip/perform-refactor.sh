#!/bin/bash

# ============================================================================
# POKER ECONOMICS REFACTOR - REPLACEMENT SCRIPT
# ============================================================================
# ⚠️  WARNING: This script modifies files in place!
# ⚠️  Make sure you have committed your changes to git before running!
#
# Run this in your project root directory:
#   chmod +x perform-refactor.sh
#   ./perform-refactor.sh /path/to/your/project
#
# Or do a DRY RUN first:
#   ./perform-refactor.sh /path/to/your/project --dry-run
# ============================================================================

PROJECT_DIR="${1:-.}"
DRY_RUN="${2:-}"

if [ "$DRY_RUN" == "--dry-run" ]; then
    echo "🔍 DRY RUN MODE - No files will be modified"
    echo ""
fi

echo "============================================================================"
echo "POKER ECONOMICS REFACTOR - REPLACEMENT SCRIPT"
echo "Project: $PROJECT_DIR"
echo "============================================================================"
echo ""

# Check if we're in a git repo
if [ -d "$PROJECT_DIR/.git" ]; then
    echo "✅ Git repository detected"
    
    # Check for uncommitted changes
    cd "$PROJECT_DIR"
    if [ -n "$(git status --porcelain)" ]; then
        echo "⚠️  WARNING: You have uncommitted changes!"
        echo "   Consider committing or stashing before proceeding."
        read -p "Continue anyway? (y/N): " confirm
        if [ "$confirm" != "y" ] && [ "$confirm" != "Y" ]; then
            echo "Aborted."
            exit 1
        fi
    fi
    cd - > /dev/null
else
    echo "⚠️  WARNING: Not a git repository - no easy way to undo changes!"
    read -p "Continue anyway? (y/N): " confirm
    if [ "$confirm" != "y" ] && [ "$confirm" != "Y" ]; then
        echo "Aborted."
        exit 1
    fi
fi

echo ""

# ============================================================================
# REPLACEMENT MAPPINGS
# ============================================================================
# Format: "OLD_NAME|NEW_NAME"
# Order matters! More specific patterns should come first.
# ============================================================================

REPLACEMENTS=(
    # Primary renames (be careful with order - longer/more specific first)
    "totalRakePerPlayerRealised|fullRakeRealized"
    "buyInsByTotalEntries|totalBuyInsCollected"
    "guaranteeOverlay|guaranteeOverlayCost"
    "guaranteeSurplus|prizepoolSurplus"
    "gameProfitLoss|gameProfit"
    "totalRake|projectedRakeRevenue"
)

# File extensions to process
FILE_EXTENSIONS=("ts" "tsx" "js" "jsx" "graphql" "json")

# Directories to exclude
EXCLUDE_DIRS=("node_modules" ".next" "dist" ".amplify" "build" ".git")

# Build find exclude arguments
build_exclude_args() {
    local args=""
    for dir in "${EXCLUDE_DIRS[@]}"; do
        args="$args -not -path '*/$dir/*'"
    done
    echo "$args"
}

EXCLUDE_ARGS=$(build_exclude_args)

# ============================================================================
# PERFORM REPLACEMENTS
# ============================================================================

TOTAL_FILES_MODIFIED=0
TOTAL_REPLACEMENTS=0

for replacement in "${REPLACEMENTS[@]}"; do
    OLD_NAME="${replacement%%|*}"
    NEW_NAME="${replacement##*|}"
    
    echo "============================================================================"
    echo "Replacing: $OLD_NAME → $NEW_NAME"
    echo "============================================================================"
    
    FILES_MODIFIED=0
    
    # Process each file extension
    for ext in "${FILE_EXTENSIONS[@]}"; do
        # Find files with this extension that contain the old name
        while IFS= read -r file; do
            if [ -n "$file" ] && [ -f "$file" ]; then
                # Check if file contains the old name
                if grep -q "$OLD_NAME" "$file" 2>/dev/null; then
                    OCCURRENCES=$(grep -c "$OLD_NAME" "$file" 2>/dev/null)
                    
                    if [ "$DRY_RUN" == "--dry-run" ]; then
                        echo "  Would update: $file ($OCCURRENCES occurrences)"
                        grep -n "$OLD_NAME" "$file" 2>/dev/null | head -3
                        if [ "$OCCURRENCES" -gt 3 ]; then
                            echo "  ... and $((OCCURRENCES - 3)) more"
                        fi
                    else
                        echo "  Updating: $file ($OCCURRENCES occurrences)"
                        # Use sed to replace (macOS compatible with backup, then remove backup)
                        if [[ "$OSTYPE" == "darwin"* ]]; then
                            sed -i '' "s/$OLD_NAME/$NEW_NAME/g" "$file"
                        else
                            sed -i "s/$OLD_NAME/$NEW_NAME/g" "$file"
                        fi
                        TOTAL_REPLACEMENTS=$((TOTAL_REPLACEMENTS + OCCURRENCES))
                    fi
                    FILES_MODIFIED=$((FILES_MODIFIED + 1))
                fi
            fi
        done < <(find "$PROJECT_DIR" -name "*.$ext" -not -path "*/node_modules/*" -not -path "*/.next/*" -not -path "*/dist/*" -not -path "*/.amplify/*" -not -path "*/build/*" -not -path "*/.git/*" 2>/dev/null)
    done
    
    echo "  Files affected: $FILES_MODIFIED"
    TOTAL_FILES_MODIFIED=$((TOTAL_FILES_MODIFIED + FILES_MODIFIED))
    echo ""
done

# ============================================================================
# SUMMARY
# ============================================================================

echo "============================================================================"
echo "REFACTOR SUMMARY"
echo "============================================================================"
echo ""

if [ "$DRY_RUN" == "--dry-run" ]; then
    echo "🔍 This was a DRY RUN - no files were modified."
    echo ""
    echo "Files that would be modified: $TOTAL_FILES_MODIFIED"
    echo ""
    echo "To perform actual replacements, run without --dry-run:"
    echo "  ./perform-refactor.sh $PROJECT_DIR"
else
    echo "✅ Replacements complete!"
    echo ""
    echo "Files modified: $TOTAL_FILES_MODIFIED"
    echo "Total replacements: $TOTAL_REPLACEMENTS"
    echo ""
    echo "NEXT STEPS:"
    echo "1. Review the changes: git diff"
    echo "2. Run 'amplify codegen' to regenerate API types"
    echo "3. Run 'amplify push' to deploy schema changes"
    echo "4. Run 'npm run build' or 'yarn build' to check for errors"
    echo "5. Test your application thoroughly"
    echo "6. If everything works, commit the changes"
fi

echo ""
echo "============================================================================"
echo "MANUAL UPDATES STILL NEEDED:"
echo "============================================================================"
echo ""
echo "The following files need manual replacement (provided separately):"
echo ""
echo "1. schema.graphql - Use the updated version provided"
echo "2. game.ts - Use the updated version provided"
echo "3. gameDataValidation.ts - Use the updated version provided"
echo "4. sg-index.js (saveGame Lambda) - Use the updated version provided"
echo "5. scraperStrategies.js - Use the updated version provided"
echo ""
echo "After replacing these files:"
echo "1. Run: amplify codegen"
echo "2. Run: amplify push"
echo "3. Create a database migration script to recalculate existing games"
echo ""
