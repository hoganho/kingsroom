# Poker Economics Refactor - Field Mapping Reference

## Overview

This document provides a complete mapping of old field names to new field names, along with formulas and usage examples.

---

## Field Mapping Table

| Old Field Name | New Field Name | Description |
|----------------|----------------|-------------|
| `totalRake` | `projectedRakeRevenue` | Intended rake: `rake × (entries + rebuys)` - ALWAYS counted as revenue |
| `buyInsByTotalEntries` | `totalBuyInsCollected` | Total money collected: `buyIn × (entries + rebuys + addons)` |
| `gameProfitLoss` | `gameProfit` | Net profit: `actualRakeRevenue - guaranteeOverlayCost` |
| `guaranteeOverlay` | `guaranteeOverlayCost` | TRUE COST: Cash paid out of pocket when buy-ins < guarantee |
| `guaranteeSurplus` | `prizepoolSurplus` | When player contributions exceed guarantee (goes to players) |
| `totalRakePerPlayerRealised` | `fullRakeRealized` | Boolean: true if we kept all projected rake |
| *(new)* | `rakeSubsidy` | Portion of projected rake redirected to prizepool |
| *(new)* | `actualRakeRevenue` | What we kept: `projectedRakeRevenue - rakeSubsidy` |
| *(new)* | `prizepoolPlayerContributions` | Player contributions: `(buyIn - rake) × (entries + rebuys) + buyIn × addons` |
| *(new)* | `prizepoolAddedValue` | Bonus to players: `rakeSubsidy + guaranteeOverlayCost` |

---

## Complete Formula Reference

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           REVENUE TRACKING                                      │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  projectedRakeRevenue = rake × (entries + rebuys)                               │
│                         → What we PLAN to collect (ALWAYS counted as revenue)   │
│                                                                                 │
│  totalBuyInsCollected = buyIn × (entries + rebuys + addons)                     │
│                         → Total money that came in the door                     │
│                                                                                 │
│  rakeSubsidy = min(guaranteeShortfall, projectedRakeRevenue)                    │
│                → Portion of rake redirected to prizepool                        │
│                                                                                 │
│  actualRakeRevenue = projectedRakeRevenue - rakeSubsidy                         │
│                      → What we ACTUALLY kept                                    │
│                                                                                 │
├─────────────────────────────────────────────────────────────────────────────────┤
│                           COST TRACKING                                         │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  guaranteeOverlayCost = max(0, guaranteeShortfall - projectedRakeRevenue)       │
│                         → Cash paid OUT OF POCKET (TRUE COST)                   │
│                         → Goes in GameCost as GUARANTEE_OVERLAY                 │
│                                                                                 │
├─────────────────────────────────────────────────────────────────────────────────┤
│                           PRIZEPOOL TRACKING                                    │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  prizepoolPlayerContributions = (buyIn - rake) × (entries + rebuys)             │
│                                 + buyIn × addons                                │
│                                 → What players contributed                      │
│                                                                                 │
│  guaranteeShortfall = max(0, guaranteeAmount - prizepoolPlayerContributions)    │
│                       → Gap we must cover                                       │
│                                                                                 │
│  prizepoolAddedValue = rakeSubsidy + guaranteeOverlayCost                       │
│                        → Total bonus players received above contributions       │
│                                                                                 │
│  prizepoolSurplus = max(0, prizepoolPlayerContributions - guaranteeAmount)      │
│                     → Extra to players when contributions exceed guarantee      │
│                                                                                 │
├─────────────────────────────────────────────────────────────────────────────────┤
│                           FINAL METRICS                                         │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  gameProfit = actualRakeRevenue - guaranteeOverlayCost                          │
│               → Net profit/loss from the tournament                             │
│                                                                                 │
│  fullRakeRealized = (rakeSubsidy === 0)                                         │
│                     → Boolean: did we keep all projected rake?                  │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## Worked Examples

### Example: $200 buy-in, $24 rake, $5,000 guarantee

| Scenario | Entries | Results |
|----------|---------|---------|
| **A: Loss** | 20 | See below |
| **B: Break-even** | 25 | See below |
| **C: Partial Rake** | 27 | See below |
| **D: Full Profit** | 30 | See below |

---

### Scenario A: 20 Entries (TRUE LOSS)

```
projectedRakeRevenue      = $24 × 20 = $480
totalBuyInsCollected      = $200 × 20 = $4,000
prizepoolPlayerContributions = ($200 - $24) × 20 = $3,520
guaranteeShortfall        = $5,000 - $3,520 = $1,480

rakeSubsidy               = min($1,480, $480) = $480  ← All rake consumed
guaranteeOverlayCost      = $1,480 - $480 = $1,000    ← OUT OF POCKET COST

actualRakeRevenue         = $480 - $480 = $0
prizepoolAddedValue       = $480 + $1,000 = $1,480
gameProfit                = $0 - $1,000 = -$1,000     ← LOSS
fullRakeRealized          = false
```

---

### Scenario B: 25 Entries (BREAK-EVEN)

```
projectedRakeRevenue      = $24 × 25 = $600
totalBuyInsCollected      = $200 × 25 = $5,000
prizepoolPlayerContributions = ($200 - $24) × 25 = $4,400
guaranteeShortfall        = $5,000 - $4,400 = $600

rakeSubsidy               = min($600, $600) = $600    ← All rake consumed
guaranteeOverlayCost      = $600 - $600 = $0          ← No out of pocket

actualRakeRevenue         = $600 - $600 = $0
prizepoolAddedValue       = $600 + $0 = $600
gameProfit                = $0 - $0 = $0              ← BREAK-EVEN
fullRakeRealized          = false
```

---

### Scenario C: 27 Entries (PARTIAL RAKE)

```
projectedRakeRevenue      = $24 × 27 = $648
totalBuyInsCollected      = $200 × 27 = $5,400
prizepoolPlayerContributions = ($200 - $24) × 27 = $4,752
guaranteeShortfall        = $5,000 - $4,752 = $248

rakeSubsidy               = min($248, $648) = $248    ← Partial rake consumed
guaranteeOverlayCost      = $248 - $648 = $0          ← No out of pocket

actualRakeRevenue         = $648 - $248 = $400
prizepoolAddedValue       = $248 + $0 = $248
gameProfit                = $400 - $0 = $400          ← REDUCED PROFIT
fullRakeRealized          = false
```

---

### Scenario D: 30 Entries (FULL PROFIT)

```
projectedRakeRevenue      = $24 × 30 = $720
totalBuyInsCollected      = $200 × 30 = $6,000
prizepoolPlayerContributions = ($200 - $24) × 30 = $5,280
guaranteeShortfall        = $5,000 - $5,280 = $0      ← No shortfall!

rakeSubsidy               = $0                         ← No subsidy needed
guaranteeOverlayCost      = $0                         ← No out of pocket

actualRakeRevenue         = $720 - $0 = $720
prizepoolSurplus          = $5,280 - $5,000 = $280    ← Extra to players
prizepoolAddedValue       = $0
gameProfit                = $720 - $0 = $720          ← FULL PROFIT
fullRakeRealized          = true
```

---

## Files Updated

1. **schema.graphql** - Game model and SaveGameDataInput
2. **game.ts** - TypeScript GameData type
3. **gameDataValidation.ts** - calculateDerivedFields function
4. **sg-index.js** - Lambda calculateFinancials function
5. **scraperStrategies.js** - calculatePokerEconomics function

---

## CostItemType Enum Addition

Added `GUARANTEE_OVERLAY` to track out-of-pocket guarantee costs in GameCost records.

---

## Refactor Scripts

Two bash scripts are provided:

1. **analyze-refactor.sh** - Analyzes your codebase and lists all occurrences of old field names
2. **perform-refactor.sh** - Performs sed-based replacements (supports --dry-run)

### Usage:

```bash
# Make scripts executable
chmod +x analyze-refactor.sh perform-refactor.sh

# Run analysis first
./analyze-refactor.sh /path/to/your/project

# Dry run to see what would change
./perform-refactor.sh /path/to/your/project --dry-run

# Perform actual replacements
./perform-refactor.sh /path/to/your/project
```

---

## Post-Refactor Steps

1. Run `amplify codegen` to regenerate API types
2. Run `amplify push` to deploy schema changes
3. Create a database migration to:
   - Add new fields to existing Game records
   - Recalculate values for existing games
4. Update any UI components displaying financial data
5. Test thoroughly before committing
